/****************************************************************************************
 * The Sentential Decision Diagram Package
 * sdd version 1.0, July 26, 2013
 * http://reasoning.cs.ucla.edu/sdd
 ****************************************************************************************/

#include "sddapi.h"
#include "compiler.h"

/****************************************************************************************
 * The dynamic vtree search algorithms tries to be selective on which parts of the
 * vtree it apply itself to. For this, it tries to identify parts of the vtree that
 * were "unchanged" since the last search and avoids these parts.
 *
 * The definition of "change" is heuristic and is based on three factors: the size of
 * sdd nodes normalized for the vtree node, in addition to the identity of its left and 
 * right children. If none of these have changed since the last search, the vtree node
 * is considered unchanged.
 *
 * To implement this strategy, once must maintain a "state" with each vtree node to keep
 * track of the previous size, left child, and right child. This is done using the
 * VtreeSearchState structure in the code below. Note, however, that the "unchanged" field 
 * in this structure has a stronger meaning: it is set to 1 iff all nodes in the vtree 
 * rooted at node are unchanged. 
 *
 * The search algorithm implements two strategies based on the notion of change:
 * 1. The algorithm will apply itself initially to the largest sub-vtree which includes
 *    a changed node
 * 2. The algorithm will treat a sub-vtree as a (virtual) leaf when all nodes in the
 *    vtree are unchanged
 *
 * The "unchanged" field is updated after each pass of the search algorithm. The update
 * function saves the search state as a side effect. The search state is also saved 
 * explicitly when the search terminates.
 ****************************************************************************************/
 
 
/****************************************************************************************
 * vtree state information for local search
 ****************************************************************************************/

// function for initializing vtree state at a node
void* initialize_node_search_state(Vtree* vtree) {
  VtreeSearchState* state = (VtreeSearchState*)malloc(sizeof(VtreeSearchState));
  state->previous_left = NULL;
  state->previous_right = NULL;
  state->previous_size = 0;
  state->unchanged = 0;
  return (void*)state;
}

// recursively initialize the search state at each vtree node
void initialize_vtree_search_state(Vtree* vtree) {
  void* search_state = initialize_node_search_state(vtree);
  sdd_vtree_set_search_state(search_state,vtree);
  if(!sdd_vtree_is_leaf(vtree)) {
    initialize_vtree_search_state(sdd_vtree_left(vtree));
    initialize_vtree_search_state(sdd_vtree_right(vtree));
  }
}

void initialize_manager_search_state(SddManager* manager) {
  Vtree* vtree = sdd_manager_vtree(manager);
  initialize_vtree_search_state(vtree);
}

// recursively free the search state at each vtree node
void sdd_vtree_free_search_state(Vtree* vtree) {
  void* search_state = sdd_vtree_search_state(vtree);
  free(search_state);
  sdd_vtree_set_search_state(NULL,vtree);
  if(!sdd_vtree_is_leaf(vtree)) {
    sdd_vtree_free_search_state(sdd_vtree_left(vtree));
    sdd_vtree_free_search_state(sdd_vtree_right(vtree));
  }
}

void sdd_manager_free_search_state(SddManager* manager) {
  Vtree* vtree = sdd_manager_vtree(manager);
  sdd_vtree_free_search_state(vtree);
}

/****************************************************************************************
 * maintaining change in the vtree since the last iteration of dynamic vtree search
 *
 * this function does the following:
 * 1. it update the "unchanged" fieled for the search state
 * 2. it update the "state" of each vtree node (size, left child, right child)
 * 3. it returns the largest sub-vtree which involved a change 
 ****************************************************************************************/

//if there was no change in the vtree in the previous search iteration, treat the vtree
//as a leaf node as far as search is concerned
int is_virtual_leaf_vtree(Vtree* vtree) {
  VtreeSearchState* state = sdd_vtree_search_state(vtree);
  return sdd_vtree_is_leaf(vtree) || state->unchanged;
}

//update the ->unchanged flag and save vtree structure
Vtree* update_change(Vtree* vtree) {
  VtreeSearchState* state = sdd_vtree_search_state(vtree);
  if(sdd_vtree_is_leaf(vtree)) {
    state->unchanged = 1;
    return NULL;
  }
  else {
    Vtree* left  = sdd_vtree_left(vtree);
    Vtree* right = sdd_vtree_right(vtree);

    Vtree* changed_left  = update_change(left);
    Vtree* changed_right = update_change(right);
   
    int local_change = (sdd_vtree_live_size_at(vtree)!=state->previous_size) || 
                       (left!=state->previous_left) || 
                       (right!=state->previous_right);
    
    //update structure
    state->previous_size = sdd_vtree_live_size_at(vtree);
    state->previous_left = left;
    state->previous_right = right;
    
    //update unchanged
    VtreeSearchState* left_state = sdd_vtree_search_state(left);
    VtreeSearchState* right_state = sdd_vtree_search_state(right);
    int flag = (!local_change && left_state->unchanged && right_state->unchanged);
    state->unchanged = flag;
    
    if(state->unchanged) return NULL; //this vtree did not change
    else if(local_change) return vtree; //this vtree changed at least locally
    else if(left_state->unchanged && !right_state->unchanged) return changed_right; //only right changed
    else if(!left_state->unchanged && right_state->unchanged) return changed_left; //only left changed
    else return vtree; //both left and right changed
  }
}


/****************************************************************************************
 * saves the search state of each node in the vtree
 ****************************************************************************************/

void save_vtree_state(Vtree* vtree) {
  if(!sdd_vtree_is_leaf(vtree)) {
    VtreeSearchState* state = sdd_vtree_search_state(vtree);
    state->previous_left = sdd_vtree_left(vtree);
    state->previous_right = sdd_vtree_right(vtree);
    state->previous_size = sdd_vtree_live_size_at(vtree);
    state->unchanged = 0;
    save_vtree_state(sdd_vtree_left(vtree));
    save_vtree_state(sdd_vtree_right(vtree));
  }
}

/****************************************************************************************
 * end
 ****************************************************************************************/
