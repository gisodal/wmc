/****************************************************************************************
 * The Sentential Decision Diagram Package
 * sdd version 1.0, July 26, 2013
 * http://reasoning.cs.ucla.edu/sdd
 ****************************************************************************************/

#include <ctype.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include "sddapi.h"
#include "compiler.h"
#include "parameters.h"

void print_help(const char* PACKAGE, int exit_value);
const char* sdd_version();

/****************************************************************************************
 * start
 ****************************************************************************************/
 
SddCompilerOptions sdd_getopt(int argc, char **argv) {
  char* PACKAGE = SDD_PACKAGE;

  //default options 
  SddCompilerOptions options = 
    {
    NULL,NULL,NULL,NULL,NULL,NULL, //file names
    1,0,0,0,0,0, //flags
    INITIAL_VTREE, 
    DYNAMIC_VTREE_CONVERGENCE_THRESHOLD,
    DYNAMIC_VTREE_INVOKE_GROWTH_FACTOR
    };
  int option;
     
  while ((option = getopt(argc,argv,"c:d:v:W:V:S:hbkmprst:e:n:")) != -1) {
    switch (option) {
    //input
    case 'c':
      options.cnf_filename = optarg;
      break;
    case 'd':
      options.dnf_filename = optarg;
      break;
    case 'v':
      options.vtree_filename = optarg;
      break;
    //output
    case 'W':
      options.output_vtree_filename = optarg;
      break;
    case 'V':
      options.output_vtree_dot_filename = optarg;
      break;
    case 'S':
      options.output_sdd_dot_filename = optarg;
      break;
    //flags
    case 'h': //HELP
      print_help(PACKAGE,0);
      break;
    case 'b': // unused
      options.construct_obdd = 1;
      break;
    case 'k': // unused
      options.check_implication = 1;
      break;
    case 'm': 
      options.minimize_cardinality = 1;
      break;
    case 'p': 
      options.dynamic_vtree_post_compilation = 1;
      break;
    case 'r':
      options.dynamic_vtree = 1;
      break;
    case 's': // unused
      options.silent = 1;
      break;
    //options with arguments
    case 't':
      options.initial_vtree_type = optarg;
      break;
    case 'e': 
      options.convergence_threshold = strtof(optarg,NULL);
      break;
    case 'n': 
      options.invoke_growth_factor = strtof(optarg,NULL);
      break;
    default:
      print_help(PACKAGE,1);
    }
  }

  //checking validity of options  
  if(options.cnf_filename==NULL && options.dnf_filename==NULL) {
    fprintf(stderr, "%s: must specify a cnf or dnf file\n",PACKAGE);
    print_help(PACKAGE,1);
  }
  if(options.cnf_filename!=NULL && options.dnf_filename!=NULL) {
    fprintf(stderr, "%s: cannot specify both cnf and dnf files (only one)\n",PACKAGE);
    print_help(PACKAGE,1);
  }
  if(strcmp(options.initial_vtree_type,"left") && 
     strcmp(options.initial_vtree_type,"right") &&
     strcmp(options.initial_vtree_type,"vertical") && 
     strcmp(options.initial_vtree_type,"balanced")) {
   fprintf(stderr, "%s: initial vtree type must be one of: left, right, vertical, or balanced\n",PACKAGE);
    print_help(PACKAGE,1);
  } 
 
  return options;
}


void print_help(const char* PACKAGE, int exit_value) {
  printf("%s: Sentential Decision Diagram, Compiler\n", PACKAGE);
  printf("%s\n",sdd_version());
  printf("%s [-c .] [-d .] [-v .]   [-w .] [-V .] [-S .]   [-h] [-m] [-p] [-r]   [t .] [-e .] [-n .]\n", PACKAGE);

  printf("  -c FILE         set input CNF file\n"); 
  printf("  -d FILE         set input DNF file\n");  
  printf("  -v FILE         set input VTREE file\n");
    
  printf("  -W FILE         set output VTREE file\n");
  printf("  -V FILE         set output VTREE (dot) file\n");
  printf("  -S FILE         set output SDD (dot) file\n");
 
  printf("  -h              print this help and exit\n");
  printf("  -m              minimize the cardinality of compiled sdd\n");
  printf("  -p              set post-compilation dynamic vtree flag\n");
  printf("  -r              set dynamic vtree flag\n");
  
  printf("  -t TYPE         set initial vtree type (left, right, vertical, or balanced)\n");
  printf("  -e NUMBER       set convergence threshold for greedy search\n");
  printf("  -n NUMBER       set sdd growth factor for invoking dynamic vtree\n");

  exit(exit_value);
}

const char* sdd_version() {
  return SDD_PACKAGE " version " SDD_VERSION ", " SDD_DATE;
}

/****************************************************************************************
 * end
 ****************************************************************************************/
