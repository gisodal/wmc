/****************************************************************************************
 * The Sentential Decision Diagram Package
 * sdd version 1.0, July 26, 2013
 * http://reasoning.cs.ucla.edu/sdd
 ****************************************************************************************/

#include "sddapi.h"
#include "compiler.h"

/****************************************************************************************
 * a key concept in this file is the "litset lca". recall that a litset is a set of 
 * literals, representing a clause or a term
 *
 * the "litset lca" can be defined in two ways: 
 * --it is the lowest vtree node that contains all variables mentioned in the litset
 * --it is the highest vtree node that mentions litset variables in both its left 
 *   and right subtrees
 *
 * the litset lca is unique and is stored in the vtree field of a litset
 *
 * this file contains two main functions:
 * 1. a function that distributes the litsets of an fnf over vtree nodes (assigns each
 *    litset to its lca)
 * 2. a function that sorts an array of listsets according to their lca (details given
 *    below)
 ****************************************************************************************/
 
#define DATA(V,F) ((VtreeData*)sdd_vtree_data(V))->F
 
// forward references
void initialize_vtree_data(Vtree* vtree);

/****************************************************************************************
 * computes a map from var indices to their (leaf) vnodes
 ****************************************************************************************/

//helper function for var2vnode_map
static void fill_var2vtree_array(Vtree* vtree, Vtree** array) {
  if(sdd_vtree_is_leaf(vtree)) array[sdd_vtree_var(vtree)]=vtree;
  else {
    fill_var2vtree_array(sdd_vtree_left(vtree),array);
    fill_var2vtree_array(sdd_vtree_right(vtree),array);
  }
}

//returns an array that maps vars to their leaf vnodes: array[var]=vnode 
Vtree** var2vtree_map(Vtree* vtree) {
  Vtree* parent=vtree;
  while(sdd_vtree_parent(parent)!=NULL) parent = sdd_vtree_parent(parent);
  //parent is now highest ancestor of vtree
  SddSize count = sdd_vtree_var_count(parent);
  Vtree** array = (Vtree**)calloc(1+count,sizeof(Vtree*));
  fill_var2vtree_array(vtree,array);
  return array;
}

/****************************************************************************************
 * marking/unmarking of vtree nodes that mention variable
 ****************************************************************************************/

//marking is done by setting the bit field of the vnode to 1
//an internal vnode mentions a variable if the variable appears in some leaf below the vnode
void mark_vnodes_mentioning_var(SddLiteral var, Vtree** var2vtree_map) {
  //leaf vnode of var
  Vtree* vtree = var2vtree_map[var];
  //mark vtree nodes that contain var
  while(vtree!=NULL && sdd_vtree_bit(vtree)!=1) {
    sdd_vtree_set_bit(1,vtree);
 	vtree=sdd_vtree_parent(vtree);
  }
}

//unmarking is done by setting the bit field of the vnode to 0
//an internal vnode mentions a variable if the variable appears in some leaf below the vnode
void unmark_vnodes_mentioning_var(SddLiteral var, Vtree** var2vtree_map) {
  //leaf vtree node of var
  Vtree* vtree = var2vtree_map[var];
  //unmark vtree nodes that contain only this var
  while(vtree!=NULL) {
    sdd_vtree_set_bit(0,vtree);
    Vtree* parent = sdd_vtree_parent(vtree);
    if(parent==NULL)
      vtree=NULL;
    else {
      Vtree* parent_left = sdd_vtree_left(parent);
      Vtree* parent_right = sdd_vtree_right(parent);
      Vtree* sibling = parent_left==vtree? parent_right: parent_left;
      //tests whether vtree is root or whether its sibling has its bit on
      if(sdd_vtree_bit(sibling)==1) vtree=NULL;
      else vtree=parent;
    }
  }
}

/****************************************************************************************
 * distributing litsets over vtree nodes
 *
 * given an fnf that consists of a number of litsets (i.e., clauses or terms), 
 * distribute these litsets over the vtree nodes
 *
 * each litset will be associated with the highest vtree node that mention litset
 * variables in both its left and right subtrees
 *
 ****************************************************************************************/

#define REALLOC(variable,type,count,message) {\
  variable = (type*) realloc(variable,(count)*sizeof(type));\
  if(variable==NULL) {\
    fprintf(stderr,"\nrealloc failed in %s\n",message);\
    exit(1);\
  }\
}

//add value to array whose elements are of type and has size
#define ADD_TO_ARRAY(type,value,array,size) {\
  ++(size);\
  REALLOC(array,type,size,"ADD_TO_ARRAY");\
  array[(size)-1] = value;\
}

//mark vtree nodes that mention variables of litset
static void mark_vnodes_of_litset(LitSet* litset, Vtree** var2vtree_map) {
  for(SddLiteral i=0; i<litset->literal_count; i++) {
    SddLiteral var = abs(litset->literals[i]);
 	mark_vnodes_mentioning_var(var,var2vtree_map);
  }
}

//unmark vtree nodes that mention variables of litset
static void unmark_vnodes_of_litset(LitSet* litset, Vtree** var2vtree_map) {
  for(SddLiteral i=0; i<litset->literal_count; i++) {
    SddLiteral var = abs(litset->literals[i]);
    unmark_vnodes_mentioning_var(var,var2vtree_map);
  }
}

//add litset to the highest vtree node that mentions litset variables in both left and right 
static void add_litset_to_vtree_litsets(LitSet* litset, Vtree* vtree) {
  Vtree* left = sdd_vtree_left(vtree);
  Vtree* right = sdd_vtree_right(vtree);
  if(sdd_vtree_is_leaf(vtree) || (sdd_vtree_bit(left)==1 && sdd_vtree_bit(right)==1)) {
    //this is THE vtree node for litset
    ADD_TO_ARRAY(LitSet*,litset,DATA(vtree,litsets),DATA(vtree,litset_count));
  }
  else if(sdd_vtree_bit(left)==1) 
    add_litset_to_vtree_litsets(litset,left);
  else 
    add_litset_to_vtree_litsets(litset,right);
}

//distribute fnf litsets over vtree nodes
//a litset belongs to the highest vtree node that mentions litset variables in both left and right vtrees
//the litset sets associated with vtree nodes must form a partition of the fnf litsets
void distribute_fnf_over_vtree(Fnf* fnf, Vtree* vtree) {
  Vtree** map = var2vtree_map(vtree);
  initialize_vtree_data(vtree);
  for(SddSize i=0; i<fnf->litset_count; i++) {
    LitSet* litset = fnf->litsets +i;
  	mark_vnodes_of_litset(litset,map);
  	add_litset_to_vtree_litsets(litset,vtree);
  	unmark_vnodes_of_litset(litset,map);
  }
  free(map);
}

/****************************************************************************************
 * computes litset lca: lowest vtree node that contains all the variables of a litset
 ****************************************************************************************/
 
static Vtree* litset2vtree_aux(LitSet* litset, Vtree* vtree) {
  Vtree* left = sdd_vtree_left(vtree);
  Vtree* right = sdd_vtree_right(vtree);

  if(sdd_vtree_is_leaf(vtree) || (sdd_vtree_bit(left)==1 && sdd_vtree_bit(right)==1)) return vtree;
  else if(sdd_vtree_bit(left)==1) return litset2vtree_aux(litset,left);
  else return litset2vtree_aux(litset,right);
}

//returns the lowest vtree node that contains all the variables of a litset
Vtree* litset2vtree(LitSet* litset, Vtree* vtree, Vtree** var_vtrees) {
  mark_vnodes_of_litset(litset,var_vtrees);
  Vtree* root = litset2vtree_aux(litset,vtree);
  unmark_vnodes_of_litset(litset,var_vtrees);
  return root;
}

/****************************************************************************************
 * sorting litsets according to their lcas (least common ancestor)
 ****************************************************************************************/

int litset_cmp_lca(const void* litset1_loc, const void* litset2_loc) {

  LitSet* litset1 = *(LitSet**)litset1_loc;
  LitSet* litset2 = *(LitSet**)litset2_loc;

  Vtree* vtree1 = litset1->vtree;
  Vtree* vtree2 = litset2->vtree;
  SddLiteral p1 = sdd_vtree_position(vtree1);
  SddLiteral p2 = sdd_vtree_position(vtree2);
  
  if(vtree1!=vtree2 && (sdd_vtree_is_sub(vtree2,vtree1) || (!sdd_vtree_is_sub(vtree1,vtree2) && (p1 > p2)))) return 1;
  else if(vtree1!=vtree2 && (sdd_vtree_is_sub(vtree1,vtree2) || (!sdd_vtree_is_sub(vtree2,vtree1) && (p1 < p2)))) return -1;
  else {
	
  SddLiteral l1 = litset1->literal_count;
  SddLiteral l2 = litset2->literal_count;
  
  if(l1 > l2) return 1;
  else if(l1 < l2) return -1;
  else { 
    //so the litset order is unique
  	//without this, final litset order may depend on system
    SddSize id1 = litset1->id;
    SddSize id2 = litset2->id;
    if(id1 > id2) return 1;
    else if(id1 < id2) return -1;
    else return 0;
  }
  }
}

//set the lca for each litset
static void set_litset_lcas(LitSet** litsets, SddSize size, Vtree* vtree, Vtree** var_vtrees) {
  while(size--) {
    LitSet* litset = *litsets++;
    litset->vtree  = litset2vtree(litset,vtree,var_vtrees);
  }
}

//first: incomparable lcas are left to right, comparabale lcas are top to down
//then: shorter to larger litsets
//last: by id to obtain unique order
void sort_litsets_by_lca(LitSet** litsets, SddSize size, Vtree* vtree, Vtree** var_vtrees) {
  //recompute lcas of litsets
  set_litset_lcas(litsets,size,vtree,var_vtrees);
  //sort
  qsort((LitSet**)litsets,size,sizeof(LitSet*),litset_cmp_lca);
}

/****************************************************************************************
 * end
 ****************************************************************************************/
