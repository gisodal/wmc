/****************************************************************************************
 * The Sentential Decision Diagram Package
 * sdd version 1.0, July 26, 2013
 * http://reasoning.cs.ucla.edu/sdd
 ****************************************************************************************/

#include "sddapi.h"
#include "compiler.h"
#include "parameters.h"

/****************************************************************************************
 * this file contains the fnf-to-sdd compiler
 ****************************************************************************************/
 
//OP: constant, which is either CONJOIN or DISJOIN
//M: manager
#define ZERO(M,OP) (OP==CONJOIN? sdd_manager_false(M): sdd_manager_true(M))
#define ONE(M,OP) (OP==CONJOIN? sdd_manager_true(M): sdd_manager_false(M))

// forward references
Vtree* dynamic_vtree(Vtree* vtree, SddManager* manager);
Vtree** var2vtree_map(Vtree* vtree);
void distribute_fnf_over_vtree(Fnf* fnf, Vtree* vtree);
void sort_litsets_by_lca(LitSet** litsets, SddSize size, Vtree* vtree, Vtree** var_vtrees);

// local declarations
static SddNode* apply_vtree(Vtree* vtree, BoolOp op, SddManager* manager);
static SddNode* apply_litsets(SddNode* base, BoolOp op, Vtree** vtree_loc, SddManager* manager);

/****************************************************************************************
 * associating litsets (clauses or terms) with the data field of vtree nodes
 ****************************************************************************************/

#define DATA(V,F) ((VtreeData*)sdd_vtree_data(V))->F
#define NEW_DATA(data) data = (VtreeData*)malloc(sizeof(VtreeData))
#define FREE_DATA(V) { free(DATA(V,litsets)); free((VtreeData*)sdd_vtree_data(V)); }

void initialize_vtree_data(Vtree* vtree) {
  void* data;
  NEW_DATA(data);
  sdd_vtree_set_data(data,vtree);
  DATA(vtree,litset_count) = 0;
  DATA(vtree,litsets) = NULL;
  if(!sdd_vtree_is_leaf(vtree)) {
    initialize_vtree_data(sdd_vtree_left(vtree));
    initialize_vtree_data(sdd_vtree_right(vtree));
  }
}

//free the fnf associated with a vtree
void free_vtree_data(Vtree* vtree) {
  if(!sdd_vtree_is_leaf(vtree)) {
    free_vtree_data(sdd_vtree_left(vtree));
    free_vtree_data(sdd_vtree_right(vtree));
  }
  FREE_DATA(vtree);
}

/****************************************************************************************
 * compiles a cnf or dnf into an sdd
 ****************************************************************************************/

//fnf is either a cnf or a dnf
SddNode* fnf_to_sdd(Fnf* fnf, SddManager* manager) {
  Vtree* vtree  = sdd_manager_vtree(manager);
  distribute_fnf_over_vtree(fnf,vtree);
  SddNode* node = apply_vtree(vtree,fnf->op,manager);
  free_vtree_data(sdd_manager_vtree(manager)); //root may have changed
  return node;
}

//each vtree node is associated with a set of litsets (clauses or terms)
//the totality of these litsets represent an fnf (cnf or dnf)
//returns an sdd which is equivalent to the associated cnf/dnf
SddNode* apply_vtree(Vtree* vtree, BoolOp op, SddManager* manager) {
  SddNode* base;

  if(sdd_vtree_is_leaf(vtree)) base = ONE(manager,op);
  else {
    SddNode* l_node = apply_vtree(sdd_vtree_left(vtree),op,manager);
    sdd_ref(l_node,manager);
    SddNode* r_node = apply_vtree(sdd_vtree_right(vtree),op,manager);
    sdd_deref(l_node,manager);
    base = sdd_apply_in_vtree(l_node,r_node,op,vtree,manager);
  }

  SddSize litset_count = DATA(vtree,litset_count);
  if(litset_count==0) return base; //no clauses stored at vtree
  
  //apply litsets may change root of vtree due to rotation
  SddNode* node = apply_litsets(base,op,&vtree,manager);

  //here instead of end of apply_litsets so we still minimize if litset_count is 0
  SddManagerOptions* options = sdd_manager_options(manager);
  if(options->dynamic_vtree) {
    sdd_ref(node,manager);
    dynamic_vtree(vtree,manager);
    sdd_deref(node,manager);
  }
  
  return node;
}

//converts a clause/term into an equivalent sdd
//all variables of litset must appear in vtree
SddNode* apply_litset(LitSet* litset, Vtree* vtree, SddManager* manager) {
  BoolOp op = litset->op;
  SddLiteral* literals = litset->literals;
  SddNode* node = ONE(manager,op); // normalized for vtree
  for(SddLiteral i=0; i<litset->literal_count; i++) {
    SddNode* l = sdd_manager_literal(literals[i],manager);
    node = sdd_apply_in_vtree(node,l,op,vtree,manager);
  }
  return node;
}

//convert the clauses/terms associated with vtree into sdds and combine them with base using op
//Vtree** instead of Vtree* since the root of vtree may be changed by dynamic_vtree
SddNode* apply_litsets(SddNode* base, BoolOp op, Vtree** vtree_loc, SddManager* manager) {
  Vtree* vtree = *vtree_loc;
  
  //get litsets associated with vtree node
  LitSet** litsets     = DATA(vtree,litsets);
  SddSize litset_count = DATA(vtree,litset_count);
  
  assert(litset_count!=0);

  Vtree** var_vtrees   = var2vtree_map(vtree); //maps variables to their leaf vtrees
  sort_litsets_by_lca(litsets,litset_count,vtree,var_vtrees);
  
  SddNode* result = base;
  sdd_ref(result,manager);
    
  //must be done after referencing
  SddSize prev_size = sdd_vtree_live_size(vtree);

  SddManagerOptions* options = sdd_manager_options(manager);
  while(litset_count--) {
    //compile and integrate litset
    SddNode* node = apply_litset(*litsets++,vtree,manager);
    sdd_deref(result,manager);
    result        = sdd_apply_in_vtree(node,result,op,vtree,manager);
    sdd_ref(result,manager);

    if(options->dynamic_vtree) {
      SddSize cur_size  = sdd_vtree_live_size(vtree); //after integrating last litset
      if(cur_size  > prev_size*options->invoke_growth_factor) {
        vtree = dynamic_vtree(vtree,manager); // root of vtree may have changed
        prev_size  = sdd_vtree_live_size(vtree); //since last call to dynamic vtree
        //recompute lcas of remaining clauses and sort
        sort_litsets_by_lca(litsets,litset_count,vtree,var_vtrees);
      }
    }
      
    SddSize dead_node_count  = sdd_vtree_dead_count(vtree);
    SddSize total_node_count = sdd_vtree_count(vtree);
    if(dead_node_count > total_node_count*DEAD_NODE_RATE) sdd_vtree_garbage_collect(vtree,manager);
  }
 
  sdd_deref(result,manager);
  *vtree_loc = vtree; //pass back new root
  free(var_vtrees);

  return result;
}

/****************************************************************************************
 * end
 ****************************************************************************************/
