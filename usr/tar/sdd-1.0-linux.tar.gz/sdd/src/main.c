/****************************************************************************************
 * The Sentential Decision Diagram Package
 * sdd version 1.0, July 26, 2013
 * http://reasoning.cs.ucla.edu/sdd
 ****************************************************************************************/

#include <time.h>
#include "sddapi.h"
#include "compiler.h"

// forward references
SddCompilerOptions sdd_getopt(int argc, char **argv);
SddNode* fnf_to_sdd(Fnf* fnf, SddManager* manager);
void free_fnf(Fnf* fnf);
Vtree* dynamic_vtree(Vtree* vtree, SddManager* manager);
char* ppc(SddSize n); // pretty print

void* initialize_manager_search_state(SddManager* manager);
void sdd_manager_free_search_state(SddManager* manager);

/****************************************************************************************
 * start
 ****************************************************************************************/
 
int main(int argc, char** argv) {

  //get options from command line (and defaults)
  SddCompilerOptions options = sdd_getopt(argc,argv);

  Fnf* fnf;
  Vtree* vtree;
  SddNode* node;
  SddManager* manager;
  clock_t c1, c2;

  if(options.cnf_filename!=NULL) {
    printf("\nreading cnf...");
    fnf = sdd_cnf_read(options.cnf_filename);
    printf("vars=%"PRIlitS" clauses=%"PRIsS"",fnf->var_count,fnf->litset_count);
  }
  else { //options.dnf_filename!=NULL
    printf("\nreading dnf...");
    fnf = sdd_dnf_read(options.dnf_filename);
    printf("vars=%"PRIlitS" terms=%"PRIsS"",fnf->var_count,fnf->litset_count);
  }
  
  if(options.vtree_filename!=NULL) {
    printf("\nreading initial vtree...");
    vtree = sdd_vtree_read(options.vtree_filename);
  } 
  else {
    printf("\ncreating initial vtree (%s)...",options.initial_vtree_type);
    vtree = sdd_vtree_new(fnf->var_count,options.initial_vtree_type);
  }
  
  printf("\ncreating manager...");
  //create manager
  manager = sdd_manager_new(vtree);
  initialize_manager_search_state(manager);
  //no longer needed
  sdd_vtree_free(vtree);
  //copying manager options from command line
  SddManagerOptions* manager_options = sdd_manager_options(manager);
  manager_options->silent = options.silent;
  manager_options->dynamic_vtree = options.dynamic_vtree;
  manager_options->convergence_threshold = options.convergence_threshold;      
  manager_options->invoke_growth_factor = options.invoke_growth_factor;

  printf("\ncompiling..."); fflush(stdout);
  c1 = clock();
  node = fnf_to_sdd(fnf,manager);
  c2 = clock();
  
  char* s;
  float secs = (float)(c2-c1)/CLOCKS_PER_SEC;
  printf("\n\ncompilation time        : %.3f sec\n",secs);
  printf(    " sdd size               : %s \n",s=ppc(sdd_size(node))); free(s);
  printf(    " sdd node count         : %s \n",s=ppc(sdd_node_count(node))); free(s);
  
  c1 = clock();
  SddModelCount mc = sdd_model_count(node,manager);
  c2 = clock();
  printf(    " sdd model count        : %s    %.3f sec\n",s=ppc(mc),(float)(c2-c1)/CLOCKS_PER_SEC); free(s);
  //printf(    "\n\n");
  
  sdd_manager_print(manager);
  
  if(options.minimize_cardinality) {
    printf("\nminimizing cardinality...");
    c1 = clock();
    node = sdd_minimize_cardinality(node,manager);
    c2 = clock();
    printf("size = %zu / node count = %zu / %.3f sec\n",sdd_size(node),sdd_node_count(node),(float)(c2-c1)/CLOCKS_PER_SEC);
  }
  
  Vtree* manager_vtree = sdd_manager_vtree(manager);

  if(options.dynamic_vtree_post_compilation) {
    sdd_ref(node,manager);
      printf("\ndynamic vtree (post compilation)\n");
      printf(    " sdd initial size       : %"PRIsS"\n",sdd_size(node));
      c1 = clock();
      dynamic_vtree(manager_vtree,manager);
      c2 = clock();
      printf("\n");
      printf(    " dynamic vtree time     : %.3f sec\n",(float)(c2-c1)/CLOCKS_PER_SEC);
      printf(    " sdd size               : %"PRIsS"\n",sdd_size(node));
      printf(    " sdd node count         : %"PRIsS"\n",sdd_node_count(node));
      printf(    " sdd model count        : %"PRImcS"\n",sdd_model_count(node,manager));
    sdd_deref(node,manager);
  }

  if(options.output_sdd_dot_filename != NULL) {
    printf("saving compiled sdd (dot)...");
    sdd_save_as_dot(options.output_sdd_dot_filename,node);
    printf("done\n");
  }

  if(options.output_vtree_filename != NULL) {
    printf("saving vtree...");
    sdd_vtree_save(options.output_vtree_filename,manager_vtree);
    printf("done\n"); 
  }

  if(options.output_vtree_dot_filename != NULL) {
    printf("saving vtree (dot)...");
    sdd_vtree_save_as_dot(options.output_vtree_dot_filename,manager_vtree);
    printf("done\n"); 
  }

  printf("freeing...");
  fflush(stdout);
  free_fnf(fnf);
  sdd_manager_free_search_state(manager);
  sdd_manager_free(manager);
  printf("done\n"); 

  return 0;
}

/****************************************************************************************
 * end
 ****************************************************************************************/
