/****************************************************************************************
 * The Sentential Decision Diagram Package
 * sdd version 1.0, July 26, 2013
 * http://reasoning.cs.ucla.edu/sdd
 ****************************************************************************************/

#include <stdio.h>
#include <stdlib.h>

/****************************************************************************************
 * this file contains the api for the sdd library: 
 * --function prototypes 
 * --associated declarations and definitions
 *
 * it also has flags for turning on assertions for choosing between 64 vs 32 versions
 ****************************************************************************************/
 
//comment the next line to activate assertions
#define NDEBUG
#include <assert.h>

#ifndef SDDAPI_H_
#define SDDAPI_H_

//comment this line out for 32bit compilation
#define _64BIT

/****************************************************************************************
 * typedefs and printf controls based on 32/64 bit
 ****************************************************************************************/

#ifdef _64BIT 
//sdd types for 64 bits
typedef size_t SddSize; //number of nodes, sizes of hash tables, etc
typedef unsigned int SddNodeSize; //size of decomposition for sdd nodes
typedef unsigned int SddRefCount; //refcount
typedef unsigned long long SddModelCount; //model counts
typedef long SddLiteral; //literals of clauses
//control strings for 64 bits
#define PRIsS "zu"
#define PRInsS "u"
#define PRIrcS "u"
#define PRImcS "llu"
#define PRIlitS "ld"
#else
//sdd types for 32 bits
typedef unsigned int SddSize; //number of nodes, sizes of hash tables, etc
typedef unsigned int SddNodeSize; //size of decomposition for sdd nodes
typedef unsigned int SddRefCount; //refcount
typedef unsigned long long SddModelCount; //model counts
typedef int SddLiteral; //literals of clauses
//control strings for 32 bits
#define PRIsS "u"
#define PRInsS "u"
#define PRIrcS "u"
#define PRImcS "llu"
#define PRIlitS "d"
#endif

typedef unsigned short BoolOp; //holds one of two values defined next
#define CONJOIN 0
#define DISJOIN 1

/****************************************************************************************
 * struct definitions
 ****************************************************************************************/

typedef struct vtree_t Vtree;
typedef struct sdd_node_t SddNode;
typedef struct sdd_manager_t SddManager;

//options
typedef struct {
  //simple options
  int silent;                  // do not print progress information during compilation
  //dynamic vtree options
  int dynamic_vtree;           // apply dynamic vtree
  float convergence_threshold; // stop greedy when reduction in size is below threshold
  float invoke_growth_factor;  // invoke dynamic vtree when width grows by factor
} SddManagerOptions;

/****************************************************************************************
 * function prototypes
 ****************************************************************************************/

// SDD MANAGER FUNCTIONS
SddManager* sdd_manager_new(Vtree* vtree);
void sdd_manager_free(SddManager* manager);
void sdd_manager_print(SddManager* manager);
SddManagerOptions* sdd_manager_options(SddManager* manager);
SddLiteral sdd_manager_var_count(SddManager* manager);

// TERMINAL SDDS
SddNode* sdd_manager_true(const SddManager* manager);
SddNode* sdd_manager_false(const SddManager* manager);
SddNode* sdd_manager_literal(const SddLiteral literal, SddManager* manager);

// SDD QUERIES AND TRANSFORMATIONS
SddNode* sdd_apply(SddNode* node1, SddNode* node2, BoolOp op, SddManager* manager);
SddNode* sdd_apply_in_vtree(SddNode* node1, SddNode* node2, BoolOp op, Vtree* vtree, SddManager* manager);
SddNode* sdd_negate(SddNode* node, SddManager* manager);
SddNode* sdd_condition(SddLiteral lit, SddNode* node, SddManager* manager);
SddNode* sdd_exists(SddLiteral var, SddNode* node, SddManager* manager);
SddNode* sdd_forall(SddLiteral var, SddNode* node, SddManager* manager);
SddModelCount sdd_model_count(SddNode* node, SddManager* manager);
SddLiteral sdd_minimum_cardinality(SddNode* node);
SddNode* sdd_minimize_cardinality(SddNode* node, SddManager* manager);
SddNode* sdd_copy(SddNode* node, SddManager* dest_manager);

// SDD FILE I/O
void sdd_save(const char* fname, SddNode *node);
SddNode* sdd_read(const char* filename, SddManager* manager);
void sdd_save_as_dot(const char* fname, SddNode *node);
void sdd_shared_save_as_dot(const char* fname, SddManager* manager);

// SDD SIZE AND NODE COUNT
//SDD
SddSize sdd_node_count(SddNode* node);
SddSize sdd_size(SddNode* node);
SddSize sdd_shared_size(SddNode** nodes, SddSize count);
//SDD OF MANAGER
SddSize sdd_manager_live_size(const SddManager* manager);
SddSize sdd_manager_dead_size(const SddManager* manager);
SddSize sdd_manager_live_count(const SddManager* manager);
SddSize sdd_manager_dead_count(const SddManager* manager);
//SDD OF VTREE
SddSize sdd_vtree_live_size(const Vtree* vtree);
SddSize sdd_vtree_live_size_at(const Vtree* vtree);
SddSize sdd_vtree_count(const Vtree* vtree);
SddSize sdd_vtree_dead_count(const Vtree* vtree);
SddSize sdd_vtree_live_count(const Vtree* vtree);

// CREATING VTREES
Vtree* sdd_vtree_new(SddLiteral var_count, const char* type);
Vtree* sdd_vtree_new_with_var_order(SddLiteral var_count, SddLiteral* var_order, const char* type);
void sdd_vtree_free(Vtree* vtree);

// VTREE FILE I/O
void sdd_vtree_save(const char* fname, Vtree* vtree);
Vtree* sdd_vtree_read(const char* filename);
void sdd_vtree_save_as_dot(const char* fname, Vtree* vtree);

// SDD MANAGER VTREE
Vtree* sdd_manager_vtree(const SddManager* manager);
Vtree* sdd_manager_vtree_copy(const SddManager* manager);

// VTREE NAVIGATION
Vtree* sdd_vtree_left(const Vtree* vtree);
Vtree* sdd_vtree_right(const Vtree* vtree);
Vtree* sdd_vtree_parent(const Vtree* vtree);

//VTREE FUNCTIONS
int sdd_vtree_is_leaf(const Vtree* vtree);
int sdd_vtree_is_sub(const Vtree* vtree1, const Vtree* vtree2);
SddLiteral sdd_vtree_var_count(const Vtree* vtree);
void sdd_vtree_var_order(SddLiteral* var_order, SddManager *manager);
SddLiteral sdd_vtree_var(const Vtree* vtree);
SddLiteral sdd_vtree_position(const Vtree* vtree);
Vtree** sdd_vtree_location(Vtree* vtree, SddManager* manager);

// VTREE/SDD EDIT OPERATIONS
int sdd_vtree_rotate_left(Vtree* vtree, SddManager* manager, SddSize time_limit, float size_limit);
int sdd_vtree_rotate_right(Vtree* vtree, SddManager* manager, SddSize time_limit, float size_limit, int max_cartesian_product);
int sdd_vtree_swap(Vtree* vtree, SddManager* manager, SddSize time_limit, float size_limit, int max_cartesian_product);

// LIMITS FOR VTREE/SDD EDIT OPERATIONS
void sdd_manager_set_initial_size_for_size_limits(Vtree* vtree, SddManager* manager);
void sdd_manager_update_initial_size_for_size_limits(SddManager* manager);

// VTREE STATE
int sdd_vtree_bit(const Vtree* vtree);
void sdd_vtree_set_bit(int bit, Vtree* vtree);
void* sdd_vtree_data(Vtree* vtree);
void sdd_vtree_set_data(void* data, Vtree* vtree);
void* sdd_vtree_search_state(const Vtree* vtree);
void* sdd_vtree_set_search_state(void* search_state, const Vtree* vtree);

// GARBAGE COLLECTION
SddRefCount sdd_ref_count(SddNode* node);
void sdd_ref(SddNode* node, SddManager* manager);
void sdd_deref(SddNode* node, SddManager* manager);
void sdd_manager_garbage_collect(SddManager* manager);
void sdd_vtree_garbage_collect(Vtree* vtree, SddManager* manager);

#endif // SDDAPI_H_

/****************************************************************************************
 * end
 ****************************************************************************************/
