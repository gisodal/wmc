/****************************************************************************************
 * The Sentential Decision Diagram Package
 * sdd version 1.0, July 26, 2013
 * http://reasoning.cs.ucla.edu/sdd
 ****************************************************************************************/

#include <stdio.h>
#include <stdlib.h>

/****************************************************************************************
 * this file contains the definitions of structures used by the fnf-to-sdd compiler and 
 * the used dynamic vtree search algorithm
 ****************************************************************************************/
 
/****************************************************************************************
 * compiler options: populated by main.c
 * some of the fields in this structure are not used
 ****************************************************************************************/
 
#ifndef COMPILER_H_
#define COMPILER_H_

typedef struct {
  //input  
  char* cnf_filename;                 // c: x, read cnf from file x
  char* dnf_filename;                 // d: x, read dnf from file x
  char* vtree_filename;               // v: x, read vtree/cnf from file x
  //output
  char* output_vtree_filename;        // W, x, write vtree to file x (as .vtree)
  char* output_vtree_dot_filename;    // V: x, write vtree to file x (as dot)
  char* output_sdd_dot_filename;      // S: x, write sdd to file x (as dot)
  //simple options
  int silent;                         // s, do not print progress information during compilation (UNUSED)
  int check_implication;              // k, check if sdd implies cnf, or is implied by dnf (UNUSED)
  int construct_obdd;                 // b, construct obdd based on the variable order embedded in final vtree (UNUSED)
  int minimize_cardinality;           // m, construct sdd that has only minimum cardinality models
  int dynamic_vtree_post_compilation; // p, apply dynamic vtree when compilation finishes
  int dynamic_vtree;                  // r, apply dynamic vtree
  //options with arguments
  char* initial_vtree_type;           // t: x, initial vtree should be of type x
  float convergence_threshold;        // e: x, stop greedy when reduction in size < x%
  float invoke_growth_factor;         // n: x, invoke dynamic vtree when width grows by x
} SddCompilerOptions;


/****************************************************************************************
 * structures for representing:
 * --cnfs and dnfs (called fnfs)
 * --clauses and terms (called litsets)
 ****************************************************************************************/
 
typedef struct {
  SddSize id;
  SddLiteral literal_count;
  SddLiteral* literals; 
  BoolOp op; //DISJOIN (clause) or CONJOIN (term)
  Vtree* vtree;
  unsigned bit:1;
} LitSet;

typedef struct {
  SddLiteral var_count; // number of variables
  SddSize litset_count; // number of literal sets
  LitSet* litsets;  // array of literal sets
  BoolOp op; //CONJOIN (CNF) or DISJOIN (DNF)
} Fnf;

typedef Fnf Cnf;
typedef Fnf Dnf;


/****************************************************************************************
 * structures for associating additional information with vtree nodes:
 * --VtreeData is used to store clauses or terms at each vtree node
 * --VtreeSearchState is used to store the state of a vtree node across vtree searches
 ****************************************************************************************/
 
typedef struct {
  SddLiteral litset_count;
  LitSet** litsets;
} VtreeData;


// local search state, stored at each vtree node
typedef struct {
  Vtree* previous_left;
  Vtree* previous_right;
  SddSize previous_size;
  unsigned unchanged:1;
} VtreeSearchState;

// these are library functions
Cnf* sdd_cnf_read(const char* filename);
Dnf* sdd_dnf_read(const char* filename);


#endif // COMPILER_H_

/****************************************************************************************
 * end
 ****************************************************************************************/
